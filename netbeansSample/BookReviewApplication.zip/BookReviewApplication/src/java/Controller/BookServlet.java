/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Book;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Elizabeth.Bourke
 */
public class BookServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //coding here 
        String action = request.getParameter("action");
        System.out.println("action = " + action);
        HttpSession session = request.getSession();

        String nextPage = "";
        switch (action) {
            case "RequestAddBook":
                nextPage = "/AddBook.html";
                break;
            case "addBook":
                nextPage = processAddBook(request, session, nextPage);
                break;
            case "home":
                nextPage = "/HomePage.jsp";
                break;
            case "EditBook":
                nextPage = processGetBookDetailsByBookID(request, session);
                break;
            case "deleteBook":
                nextPage = processDeleteBook(request, session);
                break;
            case "saveBook":
                nextPage = processSaveBook(request, session);
                break;
            case "RequestAllBooks":
                nextPage = processRequestAllBooks(session);
                break;
            default:

        }

        gotoPage(nextPage, request, response);
    }

    private String processRequestAllBooks(HttpSession session) {
        String nextPage;
        System.out.println("in display all books");
        ArrayList<Book> allBooksList = new ArrayList<>();
        Book b1 = new Book();
        allBooksList = b1.findAllBooks();
        session.setAttribute("AllBooks", allBooksList);
        nextPage = "/DisplayAllBooks.jsp";
        return nextPage;
    }

    private String processSaveBook(HttpServletRequest request, HttpSession session) throws NumberFormatException {
        String nextPage;
        System.out.println("Save book");
        //get book details 
        //get new book details from request
        //get information from the user - isbn, author price title
        String isbn = request.getParameter("isbn");
        String author = request.getParameter("author");
        String priceString = request.getParameter("price");
        String title = request.getParameter("title");
        //make price a double
        Double price = Double.parseDouble(priceString);
        String bookIDstring = request.getParameter("bookID");
        Book BookDetails = new Book(isbn, author, price, title, bookIDstring);
        String message = null;
        if (BookDetails.updateBook()) {
            message = "Book updated";
        } else {
            message = "Error on book updated";
        }
        request.setAttribute("message", message);
        //display the page again - need a new list to reflect deleted book
        return this.processRequestAllBooks(session);
    }

    private String processDeleteBook(HttpServletRequest request, HttpSession session) {
        String nextPage;
        System.out.println("Delete book");
        //get book details
        Book BookDetails = new Book();
        //get bookid from request
        String bookIDString = (String) request.getParameter("bookID");
        System.out.println("delete book for bookID =" + bookIDString);
        BookDetails.deleteBookByBookID(bookIDString);
        //display the page again - need a new list to reflect deleted book
        return this.processRequestAllBooks(session);
    }

    private String processGetBookDetailsByBookID(HttpServletRequest request, HttpSession session) throws NumberFormatException {
        String nextPage;
        System.out.println("Edit book");
        //get book details
        Book BookDetails = new Book();
        //get bookid from request
        String bookIDString = (String) request.getParameter("bookID");
        System.out.println("Edit book for bookID =" + bookIDString);
        int bookID = Integer.parseInt(bookIDString);
        BookDetails = BookDetails.findBookByBookID(bookID);
        BookDetails.print();
        session.setAttribute("Book", BookDetails);
        nextPage = "/UpdateBook.jsp";
        return nextPage;
    }

    private String processAddBook(HttpServletRequest request, HttpSession session, String nextPage) throws NumberFormatException {
        //debud info
         System.out.println("In processAddBook");
        //get information from the user - isbn, author price title
        
        String isbn = request.getParameter("isbn");
        String author = request.getParameter("author");
        String priceString = request.getParameter("price");
        String title = request.getParameter("title");
        //make price a double
        double price = Double.parseDouble(priceString);
       
        Book b = new Book(isbn, author, price, title);
        
        if (b.createBook()) {
            //send the user a message to say it was added-> view
            String message = "Book " + b.getTitle() + " was added to the system.";
            request.setAttribute("message", message);
            //display the page again - need a new list to reflect deleted book
            return this.processRequestAllBooks(session);
            
        }
        return nextPage;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void gotoPage(String url, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher
                = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

}
