/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Elizabeth.Bourke
 */
public class BookDB {

    private String BookID;

    public BookDB() {

    }

    public String getBookID() {
        return BookID;
    }

    public void setBookID(String BookID) {
        this.BookID = BookID;
    }

    private String ISBN;
    private String Author;
    private double price;
    private String Title;

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public BookDB(String ISBN, String Author, double price, String Title) {
        this.ISBN = ISBN;
        this.Author = Author;
        this.price = price;
        this.Title = Title;
    }
public BookDB(String ISBN, String Author, double price, String Title, String BookID) {
        this.ISBN = ISBN;
        this.Author = Author;
        this.price = price;
        this.Title = Title;
        this.BookID = BookID;
    }
    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String Author) {
        this.Author = Author;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public boolean createBook() {
     //   boolean inserted = false;

        Connection c = DatabaseHelper.getConnection();
        String template = "INSERT INTO Book (ISBN, Title, Author, Price) VALUES (?,?,?,?)";
        if (c != null) {
            try {
                PreparedStatement inserter = c.prepareStatement(template);
                inserter.setString(1, this.ISBN);
                inserter.setString(2, this.Title);
                inserter.setString(3, this.Author);
                inserter.setDouble(4, this.price);
                int i = inserter.executeUpdate();
                return true;
            } catch (SQLException ex) {
                System.out.println("Error on find all " + ex);
                return false;
            }
           
        }  
        return true;
    }

public Book findBookByBookID(int BookID) {
        
        Book book = null;
        System.out.println(" find all book by ID");
        Connection c = DatabaseHelper.getConnection();

        String template = "SELECT * FROM Book where BookID = ?";
        
        if (c != null) {
            try {
                PreparedStatement inserter = c.prepareStatement(template);
                inserter.setInt(1, BookID);
                ResultSet resultSet = inserter.executeQuery();
                System.out.println(inserter);
                while (resultSet.next()) {
                    book = new Book();
                    book.setBookID(resultSet.getString("BookID"));
                    book.setISBN(resultSet.getString("ISBN"));
                    book.setAuthor(resultSet.getString("Author"));
                    book.setTitle(resultSet.getString("Title"));
                    book.setPrice(resultSet.getDouble("Price"));
                   
                }
                inserter.close();
                c.close();
            } catch (SQLException ex) {
                System.out.println("Error on find all " + ex);
            }

        }
        return book;
    }    
public boolean deleteBook(String dISBN) {
     //   boolean inserted = false;

        Connection c = DatabaseHelper.getConnection();
        String template = "DELETE FROM Book WHERE ISBN = ?";
        if (c != null) {
            try {
                PreparedStatement inserter = c.prepareStatement(template);
                inserter.setString(1, dISBN);
                int i = inserter.executeUpdate();
                return true;
            } catch (SQLException ex) {
                System.out.println("Error on find all " + ex);
                return false;
            }
           
        }  
        return true;
    }
    public boolean deleteBookByBookID(String bookID) {
     //   boolean inserted = false;

        Connection c = DatabaseHelper.getConnection();
        String template = "DELETE FROM Book WHERE BookID = ?";
        if (c != null) {
            try {
                PreparedStatement inserter = c.prepareStatement(template);
                inserter.setString(1, bookID);
                int i = inserter.executeUpdate();
                return true;
            } catch (SQLException ex) {
                System.out.println("Error on find all " + ex);
                return false;
            }
           
        }  
        return true;
    }
public boolean updateBook(String ISBN) {
     //   boolean inserted = false;
        
        Connection c = DatabaseHelper.getConnection();
        String template = "UPDATE book SET ISBN = ?, Author = ?, Title = ?, Price = ? WHERE ISBN = ?";
        if (c != null) {
            try {
                PreparedStatement inserter = c.prepareStatement(template);
                
                inserter.setString(1, this.ISBN);
                inserter.setString(2, this.Author);
                inserter.setString(3, this.Title);
                inserter.setDouble(4, this.price);
                 inserter.setString(5, ISBN);
              
                int i = inserter.executeUpdate();
                return true;
            } catch (SQLException ex) {
                System.out.println("Error on update " + ex);
                return false;
            }
           
        }  
        return true;
    }
public boolean updateBook() {
     //   boolean inserted = false;

        Connection c = DatabaseHelper.getConnection();
        System.out.println("BookDB class:");
        
        String template = "UPDATE book SET ISBN = ?, Author = ?, Title = ?, Price = ? WHERE BookID = ?";
        if (c != null) {
            try {
                PreparedStatement inserter = c.prepareStatement(template);
                inserter.setString(1, this.ISBN);
                inserter.setString(2, this.Author);
                inserter.setString(3, this.Title);
                inserter.setDouble(4, this.price);
                 inserter.setString(5, this.BookID);
                    System.out.println(inserter);
                int i = inserter.executeUpdate();
                return true;
            } catch (SQLException ex) {
                System.out.println("Error on update " + ex);
                return false;
            }
           
        }  
        return true;
    }

public ArrayList<Book> findAllBooks() {

        System.out.println(" find all books");
        ArrayList<Book> allBooks = new ArrayList<Book>();

        Connection c = DatabaseHelper.getConnection();

        String template = "SELECT * FROM Book;";

        if (c != null) {
            try {
                PreparedStatement inserter = c.prepareStatement(template);
                ResultSet resultSet = inserter.executeQuery();

                while (resultSet.next()) {
                    Book b = new Book();
                    b.setBookID(resultSet.getString("BookID"));
                    b.setISBN(resultSet.getString("ISBN"));
                    b.setAuthor(resultSet.getString("Author"));
                    b.setTitle(resultSet.getString("Title"));
                    b.setPrice(resultSet.getDouble("Price"));

                    allBooks.add(b);

                }

                System.out.println(inserter);
                inserter.close();
                c.close();
            } catch (SQLException ex) {
                System.out.println("Error on find all " + ex);
            }

        }
        return allBooks;
    }

}
