/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Elizabeth.Bourke
 */
public class Book implements Serializable {

    private String ISBN;
    private String Author;
    private double price;

    private String BookID;

    /**
     * Get the value of BookID
     *
     * @return the value of BookID
     */
    public String getBookID() {
        return BookID;
    }

    /**
     * Set the value of BookID
     *
     * @param BookID new value of BookID
     */
    public void setBookID(String BookID) {
        this.BookID = BookID;
    }

    private String Title;

    public String getTitle() {
        return Title;
    }

    public Book() {
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public Book(String ISBN, String Author, double price, String Title) {
        this.ISBN = ISBN;
        this.Author = Author;
        this.price = price;
        this.Title = Title;
    }
public Book(String ISBN, String Author, double price, String Title,String BookID) {
        this.ISBN = ISBN;
        this.Author = Author;
        this.price = price;
        this.Title = Title;
        this.BookID = BookID;
    }
    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String Author) {
        this.Author = Author;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public void getUserInput() {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter ISBN");
        ISBN = s.next();
        System.out.println("Enter Author");
        Author = s.next();
        System.out.println("Enter Price");
        price = s.nextDouble();
        System.out.println("Enter Title");
        Title = s.next();
    }
    public Book findBookByBookID(int BookID) { 
         BookDB bookdb = new BookDB();
         return bookdb.findBookByBookID(BookID);
    }
    
    public ArrayList<Book> findAllBooks() { 
    
     BookDB bookdb = new BookDB();
        return bookdb.findAllBooks();
     
    }
    
    public boolean createBook(){
       
        BookDB bookdb = new BookDB(ISBN,Author,price, Title);        
        return bookdb.createBook();
    }
    
    public boolean updateBook(String ISBN){
       
        BookDB bookdb = new BookDB(ISBN,Author,price, Title);
        return bookdb.updateBook(ISBN);
    }
    public boolean updateBook(){
        System.out.println("book:update");
        this.print();
        
        BookDB bookdb = new BookDB(ISBN,Author,price, Title,BookID);
        return bookdb.updateBook();
    }
    public boolean deleteBook(String ISBN){
       
        BookDB bookdb = new BookDB();
        return bookdb.deleteBook(ISBN);
    }
    public boolean deleteBookByBookID(String bookID){
       
        BookDB bookdb = new BookDB();
        return bookdb.deleteBookByBookID(bookID);
    }
    public void print() {
        
        System.out.println("ISBN " + ISBN);
        System.out.println("Author " + Author);
        System.out.println("Title " + Title);
        System.out.println("Price " + price);
        System.out.println("****************************");

    }
}
